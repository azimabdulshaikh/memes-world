import React from "react";

export default function Index() {
   return (
      <div>
         <h1>Im Home</h1>
      </div>
   );
}
