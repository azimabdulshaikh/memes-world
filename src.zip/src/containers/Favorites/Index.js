import React, { Component } from "react";
import Wrapper from "../../hoc/Wrapper/Wrapper";
class Index extends Component() {
   state = {};

   render() {
      return (
         <div>
            <Wrapper content="Favourites" />
         </div>
      );
   }
}
export default Index;
