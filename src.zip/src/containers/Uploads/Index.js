import React, { Component } from "react";

export class Index extends Component {
   static propTypes = {};

   render() {
      return (
         <div>
            <h1> Upload index</h1>
         </div>
      );
   }
}

export default Index;
