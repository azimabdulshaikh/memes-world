import React from "react";

export default function Edit() {
   return (
      <div>
         <h1>Upload Edit</h1>
      </div>
   );
}
