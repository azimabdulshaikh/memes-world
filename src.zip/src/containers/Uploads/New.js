import React from "react";

export default function New() {
   return (
      <div>
         <h1>Upload New</h1>
      </div>
   );
}
