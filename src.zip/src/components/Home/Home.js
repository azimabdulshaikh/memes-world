import React from "react";
// import Wrapper from "../../hoc/Wrapper/Wrapper";
// import Footer from "../UI/Footer/Footer";

export const Home = () => {
   return (
      <div>
         {/* <Wrapper /> */}
         {/* <Footer /> */}
      </div>
   );
};
