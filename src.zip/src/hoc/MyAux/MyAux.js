const MyAux = (props) => props.children;
export default MyAux;
