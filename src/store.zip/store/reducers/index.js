import { combineReducers } from 'redux';
import categoryReducer from './category';
import uploadReducer from './upload';
import homeReducer from './home';
import favouriteReducer from './favourite';

const rootReducer = combineReducers({
    category:categoryReducer,
    upload:uploadReducer,
    home:homeReducer,
    favourite:favouriteReducer
});

export default rootReducer;